podman run -it -d --name tomcat -p 8082:8080 -p 8444:8443 tomcat:9.0.58
sleep 5s
podman cp server.xml tomcat:/usr/local/tomcat/conf/server.xml
sleep 3s
podman cp tomcat-users.xml tomcat:/usr/local/tomcat/conf/tomcat-users.xml
sleep 3s
podman cp ~/letsencrypt/live/ui4sql.net-0001/cert.pem tomcat:/usr/local/tomcat/conf/cert.pem
sleep 2s
podman cp ~/letsencrypt/live/ui4sql.net-0001/chain.pem tomcat:/usr/local/tomcat/conf/chain.pem
sleep 2s
podman cp ~/letsencrypt/live/ui4sql.net-0001/fullchain.pem tomcat:/usr/local/tomcat/conf/fullchain.pem
sleep 2s
podman cp ~/letsencrypt/live/ui4sql.net-0001/privkey.pem tomcat:/usr/local/tomcat/conf/privkey.pem
sleep 2s
podman cp context.xml tomcat:/usr/local/tomcat/webapps.dist/host-manager/META-INF/context.xml
sleep 2s
podman cp context.xml tomcat:/usr/local/tomcat/webapps.dist/manager/META-INF/context.xml



